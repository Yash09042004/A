package com.example.datapassing;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        ImageView imageViewLanguage = findViewById(R.id.image_view_language);
        TextView textViewLanguage = findViewById(R.id.text_view_language);

        Intent intent = getIntent();
        String language = intent.getStringExtra("language");
        int imageResId = intent.getIntExtra("imageResId", 0);

        imageViewLanguage.setImageResource(imageResId);
        textViewLanguage.setText(language);
    }
}