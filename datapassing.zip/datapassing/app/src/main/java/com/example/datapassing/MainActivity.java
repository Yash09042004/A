package com.example.datapassing;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonAndroid = findViewById(R.id.button_android);
        Button buttonCpp = findViewById(R.id.button_cpp);
        Button buttonJava = findViewById(R.id.button_java);
        Button buttonPython = findViewById(R.id.button_python);

        buttonAndroid.setOnClickListener(this);
        buttonCpp.setOnClickListener(this);
        buttonJava.setOnClickListener(this);
        buttonPython.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Button button = (Button) v;
        String language = button.getText().toString();
        int imageResId = 0;
        switch (v.getId()) {
            case R.id.button_android:
                imageResId = R.drawable.android_image;
                break;
            case R.id.button_cpp:
                imageResId = R.drawable.cpp_image;
                break;
            case R.id.button_java:
                imageResId = R.drawable.java_image;
                break;
            case R.id.button_python:
                imageResId = R.drawable.python_image;
                break;
        }
        openSecondActivity(language, imageResId);
    }

    private void openSecondActivity(String language, int imageResId) {
        Intent intent = new Intent(this, SecondActivity.class);
        intent.putExtra("language", language);
        intent.putExtra("imageResId", imageResId);
        startActivity(intent);
    }
}