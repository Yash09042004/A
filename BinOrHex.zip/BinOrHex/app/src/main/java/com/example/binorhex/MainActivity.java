package com.example.binorhex;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNumber;
    private TextView textViewResult;
    private Spinner spinnerInputType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumber = findViewById(R.id.edit_text_input);
        textViewResult = findViewById(R.id.text_view_output_type);
        spinnerInputType = findViewById(R.id.spinner_input_type);
        Button buttonConvert = findViewById(R.id.button_convert);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.input_type_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerInputType.setAdapter(adapter);

        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputType = spinnerInputType.getSelectedItem().toString();
                String numberStr = editTextNumber.getText().toString();
                if (!numberStr.isEmpty()) {
                    int number = Integer.parseInt(numberStr);
                    if (inputType.equals("Binary")) {
                        textViewResult.setText(Integer.toBinaryString(number));
                    } else if (inputType.equals("Hex")) {
                        textViewResult.setText(Integer.toHexString(number));
                    }
                }
            }
        });
    }
}