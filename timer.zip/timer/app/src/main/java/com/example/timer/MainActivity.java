package com.example.timer;



import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView timerTextView;
    private EditText timerDurationEditText;
    private Button startStopButton;
    private CountDownTimer countDownTimer;
    private boolean timerRunning;
    private long timeLeftInMilliseconds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timerTextView = findViewById(R.id.timerTextView);
        timerDurationEditText = findViewById(R.id.timerDurationEditText);
        startStopButton = findViewById(R.id.startStopButton);

        startStopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (timerRunning) {
                    stopTimer();
                } else {
                    startTimer();
                }
            }
        });
    }

    private void startTimer() {
        String durationInput = timerDurationEditText.getText().toString().trim();
        if (durationInput.isEmpty()) {
            Toast.makeText(this, "Please enter the timer duration", Toast.LENGTH_SHORT).show();
            return;
        }

        long durationInSeconds = Long.parseLong(durationInput);
        timeLeftInMilliseconds = durationInSeconds * 1000;

        countDownTimer = new CountDownTimer(timeLeftInMilliseconds, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMilliseconds = millisUntilFinished;
                updateTimerText();
            }

            @Override
            public void onFinish() {
                timerTextView.setText("00:00:00");
                timerRunning = false;
                startStopButton.setText("Start");
            }
        }.start();

        timerRunning = true;
        startStopButton.setText("Stop");
    }

    private void stopTimer() {
        countDownTimer.cancel();
        timerRunning = false;
        startStopButton.setText("Start");
    }

    private void updateTimerText() {
        int minutes = (int) (timeLeftInMilliseconds / 1000) / 60;
        int seconds = (int) (timeLeftInMilliseconds / 1000) % 60;
        int milliseconds = (int) (timeLeftInMilliseconds % 1000);

        String timeLeftFormatted = String.format("%02d:%02d:%03d", minutes, seconds, milliseconds);
        timerTextView.setText(timeLeftFormatted);
    }
}
