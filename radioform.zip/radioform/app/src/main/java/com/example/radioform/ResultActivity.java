package com.example.radioform;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    private TextView tvName, tvEmail, tvGender, tvMaritalStatus, tvTermsAccepted, tvNewsletterSubscribed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvGender = findViewById(R.id.tvGender);
        tvMaritalStatus = findViewById(R.id.tvMaritalStatus);
        tvTermsAccepted = findViewById(R.id.tvTermsAccepted);
        tvNewsletterSubscribed = findViewById(R.id.tvNewsletterSubscribed);

        // Get the data from the Intent
        String name = getIntent().getStringExtra("name");
        String email = getIntent().getStringExtra("email");
        String gender = getIntent().getStringExtra("gender");
        String maritalStatus = getIntent().getStringExtra("maritalStatus");
        boolean termsAccepted = getIntent().getBooleanExtra("termsAccepted", false);
        boolean newsletterSubscribed = getIntent().getBooleanExtra("newsletterSubscribed", false);

        // Set the data in the TextViews
        tvName.setText("Name: " + name);
        tvEmail.setText("Email: " + email);
        tvGender.setText("Gender: " + gender);
        tvMaritalStatus.setText("Marital Status: " + maritalStatus);
        tvTermsAccepted.setText("Terms Accepted: " + termsAccepted);
        tvNewsletterSubscribed.setText("Newsletter Subscribed: " + newsletterSubscribed);
    }
}
