package com.example.radioform;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText etName, etEmail;
    private RadioGroup rgGender, rgMaritalStatus;
    private RadioButton rbMale, rbFemale, rbSingle, rbMarried;
    private CheckBox cbTerms, cbNewsletter;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        rgGender = findViewById(R.id.rgGender);
        rgMaritalStatus = findViewById(R.id.rgMaritalStatus);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        rbSingle = findViewById(R.id.rbSingle);
        rbMarried = findViewById(R.id.rbMarried);
        cbTerms = findViewById(R.id.cbTerms);
        cbNewsletter = findViewById(R.id.cbNewsletter);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitForm();
            }
        });
    }

    private void submitForm() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String gender = rbMale.isChecked() ? "Male" : "Female";
        String maritalStatus = rbSingle.isChecked() ? "Single" : "Married";
        boolean termsAccepted = cbTerms.isChecked();
        boolean newsletterSubscribed = cbNewsletter.isChecked();

        // Perform form validation
        if (name.isEmpty()) {
            etName.setError("Name is required");
            return;
        }
        if (email.isEmpty()) {
            etEmail.setError("Email is required");
            return;
        }
        if (!termsAccepted) {
            cbTerms.setError("Please accept the terms and conditions");
            return;
        }

        // Submit the form data
        Intent intent = new Intent(MainActivity.this, ResultActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("email", email);
        intent.putExtra("gender", gender);
        intent.putExtra("maritalStatus", maritalStatus);
        intent.putExtra("termsAccepted", termsAccepted);
        intent.putExtra("newsletterSubscribed", newsletterSubscribed);
        startActivity(intent);
    }
}
