package com.example.url;



import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private GridLayout gridLayout;
    private List<String> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridLayout = findViewById(R.id.gridLayout);
        dataList = new ArrayList<>();

        // Add data to the list
        dataList.add("Java\tJames Gosling\twww.java.com");
        dataList.add("Python\tGuido van Rossum\twww.python.org");
        dataList.add("C++\tBjarne Stroustrup\tcplusplus.com");

        // Add rows to the GridLayout
        for (String data : dataList) {
            String[] parts = data.split("\t");
            for (String part : parts) {
                CardView cardView = new CardView(this);
                TextView textView = new TextView(this);
                textView.setText(part);
                textView.setTextSize(18);  // Increase the text size
                textView.setTypeface(null, Typeface.BOLD);  // Make the text bold
                cardView.addView(textView);
                gridLayout.addView(cardView);

                // Set click listener for the CardView
                cardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String url = parts[2];
                        openUrl(url);
                    }
                });
            }
        }
    }

    private void openUrl(String url) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://" + url;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

}